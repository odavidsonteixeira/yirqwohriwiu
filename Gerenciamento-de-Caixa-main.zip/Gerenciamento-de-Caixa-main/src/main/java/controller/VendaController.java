/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import DAO.ClienteDAO;
import model.Venda;

/**
 *
 * @author Davidson
 */
public class VendaController {
    
    Venda model = new Venda();
    ClienteDAO dao = new ClienteDAO();
    
    public void cadastrar(int idCliente,double valorCompra, String descricao) {
        model.cadastrar(idCliente, valorCompra, descricao);
    }

    public void getIDCliente(String nome) throws Exception {
        dao.getID(nome);
    }
    
    public void editar(String nome) {
        model.editar(nome);
    }
    
    public void excluir(String nome) {
        model.excluir(nome);
    }
    
    public void vizualizar(String nome) {
        model.vizualizar(nome);
    }
    
}
