# Gerenciamento-de-Caixa

# Sobre o projeto

O Gerenciamente de Caixa e um projeto voltado para aprimorarmos as boas praticas de MVC( model visual controller), sendo uma boa pratica principalemente para desenvolvedores e equipes de TI.
Projeto devido a trabalho do curso Análise e Desenvolvimento de sistemas no Centro Universitario UNA - Contagem/MG


# Tecnologias utilizadas
## Back end
- Java
- Spring Boot
- JPA / Hibernate
- Maven
## Front end
- HTML / CSS 
## Implantação em produção
- Back end: Heroku
- Front end web: A definir
- Banco de dados: A definir

# Autor

Grupo Clandestino
